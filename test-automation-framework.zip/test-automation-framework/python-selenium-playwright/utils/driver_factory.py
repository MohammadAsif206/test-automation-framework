"""
Selenium WebDriver factory with WebDriverManager and optional Remote Grid support.
"""
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.remote.webdriver import WebDriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService

from config.config import Config

log = logging.getLogger(__name__)


def create_selenium_driver() -> WebDriver:
    """Create and return a configured Selenium WebDriver."""
    browser  = Config.BROWSER
    headless = Config.HEADLESS
    grid_url = Config.GRID_URL

    if grid_url:
        return _create_remote_driver(browser, headless, grid_url)
    return _create_local_driver(browser, headless)


def _chrome_options(headless: bool) -> ChromeOptions:
    opts = ChromeOptions()
    if headless:
        opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1920,1080")
    return opts


def _create_local_driver(browser: str, headless: bool) -> WebDriver:
    if browser == "firefox":
        opts = FirefoxOptions()
        if headless:
            opts.add_argument("--headless")
        return webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()), options=opts)

    if browser == "edge":
        opts = EdgeOptions()
        if headless:
            opts.add_argument("--headless")
        return webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()), options=opts)

    # Default: Chrome
    return webdriver.Chrome(
        service=ChromeService(ChromeDriverManager().install()),
        options=_chrome_options(headless)
    )


def _create_remote_driver(browser: str, headless: bool, grid_url: str) -> WebDriver:
    log.info("Connecting to Selenium Grid: %s", grid_url)
    if browser == "firefox":
        opts = FirefoxOptions()
        if headless:
            opts.add_argument("--headless")
    elif browser == "edge":
        opts = EdgeOptions()
        if headless:
            opts.add_argument("--headless")
    else:
        opts = _chrome_options(headless)
    return webdriver.Remote(command_executor=grid_url, options=opts)
