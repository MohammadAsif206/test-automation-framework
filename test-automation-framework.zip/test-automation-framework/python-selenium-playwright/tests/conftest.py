"""
conftest.py — pytest fixtures for both Selenium and Playwright drivers.
Select engine with DRIVER=selenium or DRIVER=playwright (default).
"""
import logging
import pytest
import allure
from config.config import Config

log = logging.getLogger(__name__)


# ── Selenium fixtures ─────────────────────────────────────────────────────────

@pytest.fixture(scope="function")
def selenium_driver():
    """Yields a Selenium WebDriver and quits after the test."""
    from utils.driver_factory import create_selenium_driver
    driver = create_selenium_driver()
    driver.implicitly_wait(Config.IMPLICIT_WAIT)
    driver.maximize_window()
    yield driver
    driver.quit()
    log.info("Selenium driver closed")


# ── Playwright fixtures ───────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def playwright_instance():
    """Session-scoped Playwright instance."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        yield pw


@pytest.fixture(scope="function")
def playwright_page(playwright_instance):
    """Function-scoped Playwright browser + page."""
    browser = getattr(playwright_instance, Config.BROWSER).launch(
        headless=Config.HEADLESS,
        slow_mo=Config.SLOW_MO,
    )
    context = browser.new_context(
        viewport={"width": 1920, "height": 1080},
        record_video_dir="test-results/videos" if not Config.HEADLESS else None,
    )
    page = context.new_page()
    page.set_default_timeout(Config.DEFAULT_TIMEOUT)

    yield page

    # Capture screenshot on failure
    if hasattr(pytest, "current_test_failed") and pytest.current_test_failed:
        screenshot = page.screenshot(full_page=True)
        allure.attach(screenshot, name="screenshot", attachment_type=allure.attachment_type.PNG)

    context.close()
    browser.close()


# ── Generic 'driver' fixture — picks based on DRIVER env var ─────────────────

@pytest.fixture(scope="function")
def driver(selenium_driver, playwright_page):
    """
    Returns either Selenium WebDriver or Playwright Page based on DRIVER config.
    Usage in tests: just request `driver` and pages work with both.
    """
    if Config.DRIVER == "selenium":
        return selenium_driver
    return playwright_page


# ── Pre-authenticated fixture ─────────────────────────────────────────────────

@pytest.fixture(scope="function")
def authenticated_driver(driver):
    """Logs in and returns the driver ready on the inventory page."""
    from pages.login_page import LoginPage
    from pages.inventory_page import InventoryPage

    login = LoginPage(driver)
    login.open().login(Config.TEST_USERNAME, Config.TEST_PASSWORD)

    inventory = InventoryPage(driver)
    assert inventory.is_loaded(), "Expected to land on inventory page after login"
    return driver


# ── Hooks ─────────────────────────────────────────────────────────────────────

@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)
    if rep.when == "call" and rep.failed:
        pytest.current_test_failed = True
    else:
        pytest.current_test_failed = False
